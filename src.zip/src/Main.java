import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner scanner = new Scanner(System.in);
        String title = scanner.nextLine();
        String author = scanner.nextLine();
        int publicationYear = scanner.nextInt();
        int numberOfPages = scanner.nextInt();
        double fileSize = scanner.nextDouble();
        String format = scanner.nextLine();
        EBook eBook = new EBook(title, author, publicationYear,
                fileSize, format);
        eBook.displayDetails();
    }
}