public class PrintBook extends Book{

    private int numberOfPages;

    public PrintBook(String title, String author, int publicationYear, int numberOfPages) {
        super(title, author, publicationYear);
        this.numberOfPages = numberOfPages;
    }

    @Override
    public void displayDetails(){
        super.displayDetails();
        System.out.println(numberOfPages);
    }
}
